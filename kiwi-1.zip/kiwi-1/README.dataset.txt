# kiwi > 2024-11-18 11:15pm
https://universe.roboflow.com/ddyy/kiwi-gkp3y

Provided by a Roboflow user
License: CC BY 4.0

